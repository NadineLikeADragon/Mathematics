// MathsProject.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
void PrimeFactors(int input);
void DivAlg(int a, int b);
void ExtEucAlg(int a, int b);
int main()
{

   cout << "********************* Maths Project 1 ****************************" << endl;


    int option = 0;
    do
    {
        cout << "1.   Find the Prime factorization of a Natural Number"<< endl;
        cout << "2.   Division Algorithm" << endl;
        cout << "3.   Extended Euclidean Algorithm" << endl;
        cout << "4.   Invert a matrix of 3x3 numbers" << endl;
        cout << "5.   Exit" << endl;
        cin >> option;
        switch (option)
        {
        case 1:
        {
            int input;
            cout << "Please enter a natural number (must be greater than zero): ";
            cin >> input;
            PrimeFactors(input);
           break;
        }
        case 2:
        {
            int input1, input2;
            cout << "Please enter an integer and an integer that is not zero(2 numbers overall): ";
            cin >> input1 >> input2;
            DivAlg(input1, input2);
            break;
        }
        case 3:
        {
            int input1, input2;
            cout << "Please enter an integer and an integer that is not zero(2 numbers overall) the first integer must be greater than the second: ";
            cin >> input1 >> input2;
            ExtEucAlg(input1, input2);
            break;
        }
        case 4:
        {
            int input;
            break;
        }
        case 5:
            break;

        default:
        {
            cout << "option not implemented " << endl;
            break;
        }
        }
    } while (option != 5);
}
void PrimeFactors(int input) {
    for (int k = 2;k <=input; k++)
    {
       do{
            cout << k << endl;
            input = input / k;
       } while (input % k == 0);
    }
}
void DivAlg(int a, int b) {
    int q, r;
    if (b > 0) {
        q = a / b;
        cout << "The qoutient is: " << q << endl;
    }
    else
    {
        cout << "The input is less than 0 therefore it's an incorrect input" << endl;
    }
    r = a - (b * q);
        cout << "The remainder is: " << r << endl;
    
}
void ExtEucAlg(int a, int b) {
    int U[3] = {a,1,0};
    int V[3] = {b,0,1};
    do {
        int W;
        W = U - (U[1] / V[1]);
    } while (V[1] > 0);
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
